module.exports = {
  port: 3000,
  defaultOTPExpireTime: 15 * 60 * 1000,
  secret: "supersecret",
  user: "AutocentralUsr",
  pwd: "AutocentralAss0505",
  sendgrid_api_key: "",
  S3_AccessKey: 'AKIAUNAUQ6JJID3GVTD6',
    S3_SecretKey: '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',
    S3_BucketName: 'autocentrals3bucket',
    S3_Region: 'ap-south-1',
};
